--ADR
use master;
GO
DROP DATABASE IF EXISTS DB01;

DROP DATABASE IF EXISTS DBADR;

CREATE DATABASE DB01;

CREATE DATABASE DBADR;

ALTER DATABASE DBADR SET ACCELERATED_DATABASE_RECOVERY = ON;


-----
-- set the right start time
--session 1
WAITFOR TIME '13:07:00';
USE DB01;
GO
DROP TABLE IF EXISTS dbt.fl1, dbo.fl2, dbo.fl3;
SELECT s2.* INTO dbo.fl1 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;
SELECT s2.* INTO dbo.fl2 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;
SELECT s2.* INTO dbo.fl3 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;


-----
--session 2
WAITFOR TIME '13:07:00';
USE DBADR;
GO
DROP TABLE IF EXISTS dbt.fl1, dbo.fl2, dbo.fl3;
SELECT s2.* INTO dbo.fl1 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;
SELECT s2.* INTO dbo.fl2 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;
SELECT s2.* INTO dbo.fl3 FROM sys.all_columns AS s1 CROSS JOIN sys.all_objects as S2;


--
--session 3
WAITFOR DELAY '00:01:30'
SHUTDOWN WITH NOWAIT;


--Check LDF Files
--Check SQL Error Log









































--Recovery completed for database DBADR (database ID 14) in 2 second(s) (analysis 799 ms, redo 168 ms, undo 24 ms [system undo 0 ms, regular undo 0 ms].) This is an informational mess
--Recovery completed for database DB01 (database ID 13) in 8 second(s) (analysis 5137 ms, redo 1783 ms, undo 192 ms [system undo 0 ms, regular undo 156 ms].) This is an informational message only. No user action is required.
