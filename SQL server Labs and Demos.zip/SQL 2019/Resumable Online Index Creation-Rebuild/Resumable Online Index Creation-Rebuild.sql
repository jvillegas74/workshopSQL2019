-- RESUMABLE ONLINE INDEX REBUILD (SQL 2017)

use Interlink_Main90
go

--drop table if exists DBA.dbo.TMP_Index_Frag
--GO
DELETE FROM DBA.dbo.TMP_Index_Frag WHERE [Database] = db_name()
TRUNCATE TABLE DBA.dbo.TMP_Index_Frag;
-- Check index fragmentation Level
INSERT INTO DBA.dbo.TMP_Index_Frag
SELECT  
		--db_name() as [Database],
		NULL as [Database],
		dbschemas.[name] as [Schema],
		dbtables.[name] as [Table],
		dbindexes.[name] as [Index],
		dbindexes.[Index_id] as [Index_ID],
		cast(indexstats.avg_fragmentation_in_percent as Decimal(5,2)) as FragmentationPercent,
		indexstats.page_count as PageCount,
		RW.[RowCount]
    --INTO DBA.dbo.TMP_Index_Frag
	FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
		INNER JOIN sys.tables dbtables 
			ON dbtables.[object_id] = indexstats.[object_id]
		INNER JOIN sys.schemas dbschemas 
			ON dbtables.[schema_id] = dbschemas.[schema_id]
		INNER JOIN sys.indexes dbindexes 
			ON dbindexes.[object_id] = indexstats.[object_id]
		AND indexstats.index_id = dbindexes.index_id
		INNER JOIN (
			SELECT
				sObj.object_id
				,QUOTENAME(SCHEMA_NAME(sOBJ.schema_id)) + '.' + QUOTENAME(sOBJ.name) AS [TableName]
				, SUM(sPTN.Rows) AS [RowCount]
			FROM 
				sys.objects AS sOBJ
				INNER JOIN sys.partitions AS sPTN
					ON sOBJ.object_id = sPTN.object_id
			WHERE
				sOBJ.type = 'U'
				AND sOBJ.is_ms_shipped = 0x0
				AND index_id < 2 -- 0:Heap, 1:Clustered
			GROUP BY 
			sObj.object_id
			, sOBJ.schema_id
			, sOBJ.name
		) RW on dbtables.object_id=RW.object_id
	--WHERE indexstats.database_id = DB_ID()
		--and dbtables.[name] = 'orders' 
		--and dbindexes.[name] = 'o_orderdate_ind';
		--and RW.[RowCount] > 3000000
		--and  dbtables.[name] like 'A_Table%'
    ORDER BY RW.[RowCount] desc
GO
select *, 
'ALTER INDEX ['+[Index]+'] ON ['+[schema]+'].['+[Table]+'] REBUILD WITH (RESUMABLE = ON, ONLINE = ON (WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 1 MINUTES, ABORT_AFTER_WAIT = SELF )));' as [Rebuild_LowPriority],
'ALTER INDEX ['+[Index]+'] ON ['+[schema]+'].['+[Table]+'] REBUILD WITH (RESUMABLE = ON, ONLINE = ON);' as [Rebuild],
'ALTER INDEX ['+[Index]+'] ON ['+[schema]+'].['+[Table]+'] PAUSE;' as [Pause],
'ALTER INDEX ['+[Index]+'] ON ['+[schema]+'].['+[Table]+'] RESUME;' as [Resume],
'ALTER INDEX ['+[Index]+'] ON ['+[schema]+'].['+[Table]+'] ABORT;' as [Abort]
from DBA.dbo.TMP_Index_Frag  (NOLOCK) 
WHERE Index_id > 0 and /*[Database] = db_name() and */ [RowCount] > 10000 and FragmentationPercent > 1
ORDER BY 
[table],Index_ID
GO


ALTER INDEX [EQDT_eqev_Type_date] ON [dbo].[Equipment_Detail] REBUILD WITH (RESUMABLE = ON, ONLINE = ON (WAIT_AT_LOW_PRIORITY ( MAX_DURATION = 1 MINUTES, ABORT_AFTER_WAIT = SELF )));
ALTER INDEX [EQDT_eqev_Type_date] ON [dbo].[Equipment_Detail] REBUILD WITH (RESUMABLE = ON, ONLINE = ON);	
ALTER INDEX [EQDT_eqev_Type_date] ON [dbo].[Equipment_Detail] PAUSE;	
ALTER INDEX [EQDT_eqev_Type_date] ON [dbo].[Equipment_Detail] RESUME;	
ALTER INDEX [EQDT_eqev_Type_date] ON [dbo].[Equipment_Detail] ABORT;


---- !!! -------- New Session ----------------------
exec dbo.SP_DBA_CurrentlyExec
--exec dbo.SP_WhoIsActive

--Check execution % completed
SELECT total_execution_time, percent_complete, page_count, object_id,index_id,name,sql_text,last_max_dop_used,partition_number,state,state_desc,start_time,last_pause_time,total_execution_time
	FROM  sys.index_resumable_operations;



	select database_id,db_name() as [Database],total_log_size_mb,active_vlf_count,active_log_size_mb,log_truncation_holdup_reason,log_backup_time, log_since_last_log_backup_mb,cast((log_since_last_log_backup_mb*100)/total_log_size_mb as decimal(10,2)) as [% Log Used]
from sys.dm_db_log_stats(db_id()) 

select object_name,counter_name,instance_name,cntr_value from sys.dm_os_performance_counters
		where object_name = 'SQLServer:Databases'
		and counter_name in ('Percent Log Used')
		and instance_name = db_name()	

-----------------------------------------------------------------------------------------------

-- RESUMABLE ONLINE INDEX CREATION (SQL 2019)
USE WideWorldImportersDW
GO
CREATE INDEX IDX_1 ON Fact.OrderHistory([City Key],[Salesperson Key]) INCLUDE ([WWI Backorder ID]) WITH (ONLINE=ON,RESUMABLE=ON)


